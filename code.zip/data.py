import os
import cv2
import numpy as np
from sklearn.decomposition import PCA
def get_training_data(dir_path):
	dirs=os.listdir(dir_path)
	persons=[]
	for dir in dirs:
		dir_check=dir_path+"/"+dir
		if not os.path.isfile(dir_check):
			persons.append(dir)
		#print(y_train)

	x_train=[]
	y_train=[]

	person_dict=dict(zip(persons,np.arange(len(persons))))

	for person in persons:
		img_path=dir_path+"/"+person
		images=os.listdir(img_path)
	
		for image in images:
			img=cv2.imread(img_path+"/"+image,0)
			resized=cv2.resize(img,(280,280))
			x_train.append(resized)
			y_train.append(person_dict[person])
	
	x_train=np.array(x_train)
	y_train=np.array(y_train)


	
	pca = PCA(.90)
	a,b,c=x_train.shape
	x_train=x_train.reshape(a,b*c)
	x_train=pca.fit_transform(x_train)
	print(x_train.shape)


	return x_train,y_train

